/*
 * threadgroup.h
 *
 *  Created on: 2014-6-23
 *      Author: root
 */

#ifndef THREADGROUP_H_
#define THREADGROUP_H_

#include <set>
#include <mutex>
#include <thread>
#include <vector>
#include <unordered_map>

using namespace std;

namespace ZL {
namespace Thread {

class thread_group {
private:
	thread_group(thread_group const&);
	thread_group& operator=(thread_group const&);
public:
	thread_group() {
	}
	~thread_group() {
		for (auto &th : threads) {
			delete th.second;
		}
	}

	/********************************************************************
	* Description：检测本线程是是否在线程库中
	* Return:
	*********************************************************************/
	bool is_this_thread_in() {
		auto it = threads.find(this_thread::get_id());
		return it != threads.end();
	}

	/********************************************************************
	* Description：查找线程库中是否存在某个线程
	* Return：ture-找到线程，false-没有找到
	**********************************************************************/
	bool is_thread_in(thread* thrd) {
		if (thrd) {
			auto it = threads.find(thrd->get_id());
			return it != threads.end();
		} else {
			return false;
		}
	}

	template<typename F>

	/*****************************************************************
	* Description:创建一个线程对象
	* Return:线程对象的指针
	******************************************************************/
	thread* create_thread(F threadfunc) {
		thread  *new_thread=new thread(threadfunc);
		threads[new_thread->get_id()] = new_thread;
		return new_thread;
	}

	/******************************************************************
	* Description:将一个线程对象加入到线程库中
	********************************************************************/
	void add_thread(thread* thrd) {
		if (thrd) {
			if (is_thread_in(thrd)) {
				throw runtime_error(
						"thread_group: trying to add a duplicated thread");
			}
			threads[thrd->get_id()] = thrd;
		}
	}

	/*********************************************************************
	* Description:从线程库中将某个线程删除
	**********************************************************************/
	void remove_thread(thread* thrd) {
		auto it = threads.find(thrd->get_id());
		if (it != threads.end()) {
			threads.erase(it);
		}
	}
	void join_all() {
		if (is_this_thread_in()) {
			throw runtime_error("thread_group: trying joining itself");
			return;
		}
		for (auto &it : threads) {
			if (it.second->joinable()) {
				it.second->join(); //等待线程主动退出
			}
		}
	}

	/**********************************************************************
	* Description:线程库中，所有下线程对象的总和
	************************************************************************/
	size_t size() {
		return threads.size();
	}
private:
	unordered_map<thread::id, thread*> threads; /*存储所有的线程对象*/

};

} /* namespace Thread */
} /* namespace ZL */
#endif /* THREADGROUP_H_ */
