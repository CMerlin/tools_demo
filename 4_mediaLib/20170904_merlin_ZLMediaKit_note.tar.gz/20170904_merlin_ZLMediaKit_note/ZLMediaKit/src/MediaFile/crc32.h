/*
 * crc32.h
 *
 *  Created on: 2013-6-21
 *      Author: root
 */

#ifndef CRC32_H_
#define CRC32_H_

unsigned int  calc_crc32 (unsigned char *data, unsigned int datalen);
unsigned int Zwg_ntohl(unsigned int s);



#endif /* CRC32_H_ */
