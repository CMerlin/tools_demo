#include <stdexcept>
#include "PipeWrap.h"
#include "Util/util.h"
#include "Util/uv_errno.h"
#include "Network/sockutil.h"

using namespace std;
using namespace ZL::Util;
using namespace ZL::Network;

#define checkFD(fd) \
	if (fd == -1) { \
		clearFD(); \
		throw runtime_error((StrPrinter << "create windows pipe failed:" << get_uv_errmsg()).operator<<(endl));\
	}

#define closeFD(fd) \
	if (fd != -1) { \
		close(fd);\
		fd = -1;\
	}

namespace ZL {
namespace Poller {

PipeWrap::PipeWrap(){

/*********************************************************************************************
* Description:此构造函数的作用是，创建两个套接字（一个做TCP服务器端一个TCP客户端）
*********************************************************************************************/
#if defined(_WIN32)
	_listenerFd = SockUtil::listen(0, "127.0.0.1"); /*创建一个TCP服务器端并监听*/
	checkFD(_listenerFd); /*检测文件描述符是否小于0*/
	SockUtil::setNoBlocked(_listenerFd,false); /*设置此套接字是非阻塞的*/
	auto localPort = SockUtil::get_local_port(_listenerFd); /*得到本套接字的端口号*/
	_pipe_fd[1] = SockUtil::connect("127.0.0.1", localPort,false);
	checkFD(_pipe_fd[1])
	_pipe_fd[0] = accept(_listenerFd, nullptr, nullptr);
	checkFD(_pipe_fd[0])

#else
	if (pipe(_pipe_fd) == -1) {
		throw runtime_error((StrPrinter << "create posix pipe failed:" << get_uv_errmsg()).operator<<(endl));\
	}
#endif // defined(_WIN32)	
	SockUtil::setNoBlocked(_pipe_fd[0],true);
	SockUtil::setNoBlocked(_pipe_fd[1],false);
}

/*****************************************************************************************************
* Description:将本对象中，析构函数中创建的所有套接字文件都关闭
******************************************************************************************************/
void PipeWrap::clearFD() {
	closeFD(_pipe_fd[0]);
	closeFD(_pipe_fd[1]);

#if defined(_WIN32)
	closeFD(_listenerFd);
#endif // defined(_WIN32)

}
PipeWrap::~PipeWrap(){
	clearFD();
}

/*************************************************************************************************
* Description:向TCP服务器端发送数据
************************************************************************************************/
int PipeWrap::write(const void *buf, int n) {
#if defined(_WIN32)
	return send(_pipe_fd[1], (char *)buf, n, 0);
#else
	return ::write(_pipe_fd[1],buf,n);
#endif // defined(_WIN32)
}

/**************************************************************************************************
* Description:TCP服务器服务器端接收数据
***************************************************************************************************/
int PipeWrap::read(void *buf, int n) {
#if defined(_WIN32)
	return recv(_pipe_fd[0], (char *)buf, n, 0);
#else
	return ::read(_pipe_fd[0], buf, n);
#endif // defined(_WIN32)
}

} /* namespace Poller */
} /* namespace ZL*/
