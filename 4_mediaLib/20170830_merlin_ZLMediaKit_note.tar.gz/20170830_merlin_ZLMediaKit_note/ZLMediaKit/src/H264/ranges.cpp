//
//  ranges.cpp
//  MediaPlayer
//
//  Created by xzl on 2017/1/13.
//  Copyright © 2017年 jizan. All rights reserved.
//

#include "ranges.h"
